# 📄 Panduan Update Konten Website KK Fotocopy

Berikut adalah panduan untuk memperbarui gambar dan teks pada beberapa bagian di halaman utama.

---

## 🔵 1. Update Bagian **"Pilihan Terpopuler"**

Untuk mengganti gambar placeholder di card produk populer, lakukan langkah berikut:

### ➤ Lokasi File
Simpan gambar baru sebagai:

```html
public/images/banner.png
```

### ➤ Cara Mengubah
Edit file `home.blade.php` pada bagian kartu produk, lalu ganti path gambarnya:

Dari:
```html
<div class="popular-card-image mb-3"></div>
```
Menjadi:
```html
<img src="{{ asset('images/banner.png') }}" alt="Cetak Banner">
```

🟢 2. Update Bagian "Cepat & Tepat Waktu"

Untuk mengganti gambar placeholder abu-abu di fitur utama:

➤ Lokasi File

Simpan gambar baru di:
```html
public/images/cepat-tepat.png
```
➤ Cara Mengubah

Dari
```html
<div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>
```

Ubah tag gambar menjadi:
```html
<img src="{{ asset('images/cepat-tepat.png') }}" alt="Cepat & Tepat">
```

