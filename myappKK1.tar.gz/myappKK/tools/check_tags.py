import re
from pathlib import Path
p = Path(r"d:/Kuliah/Semester 1/Algoritma dan Pemrograman/myappKK/resources/views/home.blade.php")
s = p.read_text(encoding='utf-8')
pattern = re.compile(r'<\s*(/)?\s*([a-zA-Z][a-zA-Z0-9\-]*)([^>]*)>', re.DOTALL)
voids = set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'])
stack = []
problems = []
for m in pattern.finditer(s):
    is_close = m.group(1) == '/'
    tag = m.group(2).lower()
    rest = m.group(3)
    start = m.start()
    line = s.count('\n', 0, start) + 1
    self_closing = rest.strip().endswith('/')
    if is_close:
        if not stack:
            problems.append((line, f"Closing tag </{tag}> without opening"))
        else:
            top, top_line = stack[-1]
            if top == tag:
                stack.pop()
            else:
                found = False
                for i in range(len(stack)-1, -1, -1):
                    if stack[i][0] == tag:
                        found = True
                        break
                if found:
                    problems.append((line, f"Closing </{tag}> but top of stack is <{stack[-1][0]}> (opened at line {stack[-1][1]})"))
                    while stack and stack[-1][0] != tag:
                        stack.pop()
                    if stack:
                        stack.pop()
                else:
                    problems.append((line, f"Closing tag </{tag}> without matching opening in stack"))
    else:
        if tag in voids or self_closing:
            continue
        if tag.startswith('!') or tag.startswith('?'):
            continue
        stack.append((tag, line))
for tag,line in stack:
    problems.append((line, f"Unclosed <{tag}> opened here"))
problems.sort()
if problems:
    for ln,msg in problems:
        print(f"Line {ln}: {msg}")
else:
    print('No tag problems found')
print('\nTotal tags found:', len(list(pattern.finditer(s))))
