<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800&display=swap"
    rel="stylesheet">

<footer class="footer">
    <div class="card-group">
        <div class="card border-0">
            <div class="card-body">
                <a class="navbar-brand" href="{{ route('home') }}">
                    <div class="navbar-brand-content">
                        <img src="{{ asset('images/logo.svg') }}" alt="Logo" height="40" style="border-radius: 4px;">
                        <div class="navbar-brand-text">
                            <span class="navbar-brand-name navbar-brand-name-custom d-block">KK FOTOCOPY</span>
                            <span class="navbar-brand-subtitle">Solusi Cetak Cepat, Hasil Tepat</span>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="card border-0">
            <div class="card-body">
                <h5 class="fs-5 fw-medium">Navigasi Cepat</h5>
                <ul class="footer-list-menu">
                    <li class="mb-2"><a href="#" class="fs-6">Beranda</a></li>
                    <li class="mb-2"><a href="#" class="fs-6">Produk & Layanan</a></li>
                    <li class="mb-2"><a href="#" class="fs-6">Lokasi</a></li>
                    <li class="mb-2"><a href="#" class="fs-6">Kontak</a></li>
                </ul>
            </div>
        </div>
        <div class="card border-0">
            <div class="card-body">
                <h5 class="fs-5 fw-medium">Social Media</h5>
                <div class="social-icons">
                    <a href="https://wa.me/6282227273641" target="_blank" class="fs-4 social-icons-wa"><i class="fab fa-whatsapp"></i></a>
                    <a href="#" class="fs-4 social-icons-ig"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>