// Smooth scroll section (punya kamu sebelumnya) ... tetap biarkan

// Horizontal scroll dengan mouse wheel untuk .popular-list
document.addEventListener('DOMContentLoaded', function () {
    const popularList = document.querySelector('.popular-list');
    if (popularList) {
        popularList.addEventListener('wheel', function (e) {
            // kalau mau scroll horizontal saat mouse di area card
            e.preventDefault();
            popularList.scrollLeft += e.deltaY;
        }, { passive: false });
    }
});

document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        // Abaikan jika cuma "#" saja (biar gak error)
        if (href === '#') return;

        const target = document.querySelector(href);
        if (target) {
            e.preventDefault();
            
            // 1. Jalankan Smooth Scroll
            target.scrollIntoView({ behavior: 'smooth' });

            // 2. TUTUP NAVBAR (PENTING!)
            // Cari elemen menu yang sedang terbuka
            const navbarCollapse = document.querySelector('.navbar-collapse');
            if (navbarCollapse.classList.contains('show')) {
                // Gunakan class bawaan Bootstrap untuk menutup
                const bsCollapse = new bootstrap.Collapse(navbarCollapse);
                bsCollapse.hide();
            }
        }
    });
});
console.log("script.js jalan");


window.initMap = function () {
    const lokasi = { lat: -6.200000, lng: 106.816666 };

    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 13,
        center: lokasi,
    });

    new google.maps.Marker({
        position: lokasi,
        map: map,
        title: "Lokasi KK Fotocopy"
    });
};


// js gemini ai

// Fungsi untuk memindahkan class active saat scroll
const sections = document.querySelectorAll("section[id]");

window.addEventListener("scroll", () => {
    let current = "";
    sections.forEach((section) => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (pageYOffset >= sectionTop - 100) { // Offset 100px agar trigger lebih awal
            current = section.getAttribute("id");
        }
    });

    document.querySelectorAll(".nav-link").forEach((link) => {
        link.classList.remove("active");
        if (link.getAttribute("href").includes(current)) {
            link.classList.add("active");
        }
    });
});
