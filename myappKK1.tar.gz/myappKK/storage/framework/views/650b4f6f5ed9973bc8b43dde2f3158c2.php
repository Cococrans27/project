<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact - <?php echo e(config('app.name', 'Laravel')); ?></title>
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
            <link rel="preconnect" href="https://fonts.bunny.net">
            <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
        <?php endif; ?>
    </head>
    <body class="bg-[#FDFDFC] dark:bg-[#0a0a0a] mt-5" style="padding-top: 3rem;">
        <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kontak & Sosial Media</title>

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="style.css">
</head>
<body>

<section class="contact-section">
    <h2>Kontak & Sosial Media</h2>
    <p class="subtitle">Hubungi kami kapan saja.</p>
    <span class="divider"></span>

    <div class="card-wrapper">

        <!-- Card 1 -->
        <div class="contact-card">
            <i class="fab fa-whatsapp icon-title"></i>
            <h3>WhatsApp</h3>
            <p class="desc">Kirimkan file & berkasmu di sini</p>

            <div class="icon-circle"></div>

            <p class="contact-info">0822-2727-6341</p>
            <a href="#" class="btn">Hubungi Sekarang</a>
        </div>

        <!-- Card 2 -->
        <div class="contact-card">
            <i class="fab fa-whatsapp icon-title"></i>
            <h3>WhatsApp</h3>
            <p class="desc">Pesan dalam jumlah banyak</p>

            <div class="icon-circle"></div>

            <p class="contact-info">0812-3577-3821</p>
            <a href="#" class="btn">Hubungi Sekarang</a>
        </div>

        <!-- Card 3 -->
        <div class="contact-card">
            <i class="fab fa-instagram icon-title"></i>
            <h3>Instagram</h3>
            <p class="desc">Lihat portofolio & promo terbaru</p>

            <div class="icon-circle"></div>

            <p class="contact-info">@kkgroupid</p>
            <a href="#" class="btn">Ikuti Sekarang</a>
        </div>
            <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    </div>
</section>

</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Footer KK Fotocopy</title>
    <link rel="stylesheet" href="style.css">

    <!-- Font Awesome untuk icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<footer class="footer">
    <div class="footer-container">

        <!-- Kiri -->
        <div class="footer-left">
            <img src="logo.png" alt="KK Fotocopy" class="logo">
            <h3>KK Fotocopy</h3>
            <p>Solusi Cetak Cepat, Hasil Tepat.</p>
        </div>

        <!-- Tengah -->
        <div class="footer-center">
            <h4>Navigasi Cepat</h4>
            <ul>
                <li><a href="#">Beranda</a></li>
                <li><a href="#">Produk & Layanan</a></li>
                <li><a href="#">Lokasi</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
        </div>

        <!-- Kanan -->
        <div class="footer-right">
            <h4>Social Media</h4>
            <div class="social-icons">
                <a href="#"><i class="fab fa-whatsapp"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>

    </div>
</footer>

</body>
</html>


        <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <h1 class="text-4xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-8">
                Kontak & Sosial Media 
            </h1>
            <h1 class="text-2xl font-semibold text-[#1b1b18] dark:text-[#EDEDEC] mb-6">
                Hubungi Kami Kapan Saja
            </h1>
            <div class="max-w-2xl">
                <form class="space-y-6">
                    <div>
                        <label class="block text-[#1b1b18] dark:text-[#EDEDEC] mb-2">Nama</label>
                        <input type="text" class="w-full px-4 py-2 border border-[#e3e3e0] dark:border-[#3E3E3A] bg-white dark:bg-[#161615] text-[#1b1b18] dark:text-[#EDEDEC] rounded-sm focus:outline-none focus:border-[#1b1b18]" placeholder="Nama Anda">
                    </div>
                    <div>
                        <label class="block text-[#1b1b18] dark:text-[#EDEDEC] mb-2">Email</label>
                        <input type="email" class="w-full px-4 py-2 border border-[#e3e3e0] dark:border-[#3E3E3A] bg-white dark:bg-[#161615] text-[#1b1b18] dark:text-[#EDEDEC] rounded-sm focus:outline-none focus:border-[#1b1b18]" placeholder="Email Anda">
                    </div>
                    <div>
                        <label class="block text-[#1b1b18] dark:text-[#EDEDEC] mb-2">Pesan</label>
                        <textarea class="w-full px-4 py-2 border border-[#e3e3e0] dark:border-[#3E3E3A] bg-white dark:bg-[#161615] text-[#1b1b18] dark:text-[#EDEDEC] rounded-sm focus:outline-none focus:border-[#1b1b18]" rows="5" placeholder="Pesan Anda"></textarea>
                    </div>
                    <button type="submit" class="px-6 py-3 bg-[#1b1b18] dark:bg-[#eeeeec] text-white dark:text-[#1C1C1A] rounded-sm font-medium hover:bg-[#333333] dark:hover:bg-white transition-colors">
                        Kirim Pesan
                    </button>
                </form>
            </div>
        </main>


    </body>
</html>
<?php /**PATH C:\projects\myappKK\resources\views/contact.blade.php ENDPATH**/ ?>