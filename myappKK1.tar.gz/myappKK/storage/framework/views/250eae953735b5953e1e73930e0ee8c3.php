<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Services - <?php echo e(config('app.name', 'Laravel')); ?></title>
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
            <link rel="preconnect" href="https://fonts.bunny.net">
            <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
        <?php endif; ?>
    </head>
    <body class="bg-[#FDFDFC] dark:bg-[#0a0a0a] mt-5" style="padding-top: 3rem;">
        <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

         <section class="py-5">
    <div class="container">
        <h4 class="text-center mb-3">Temukan Kami Disini</h4>
        <h6 class="text-center mb-4">Datang Langsung, Kami Siap Bantu Kebutuhan cetakmu.</h6>
        
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d247.1987929623117!2d112.6973135!3d-7.5552679!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7df004ad94b25%3A0xba6706a9d1ce2c1b!2sKK%20Fotokopi%20(Cabang%20Utama)!5e0!3m2!1sid!2sid!4v1766032300754!5m2!1sid!2sid" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

        <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <h1 class="text-4xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-8">
                Layanan Kami
            </h1>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="p-6 border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-lg">
                    <h2 class="text-xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-3">Konsultasi</h2>
                    <p class="text-[#706f6c] dark:text-[#A1A09A]">Layanan konsultasi profesional untuk kebutuhan bisnis Anda</p>
                </div>
                <div class="p-6 border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-lg">
                    <h2 class="text-xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-3">Pengembangan</h2>
                    <p class="text-[#706f6c] dark:text-[#A1A09A]">Pengembangan solusi custom sesuai dengan kebutuhan Anda</p>
                </div>
                <div class="p-6 border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-lg">
                    <h2 class="text-xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-3">Dukungan</h2>
                    <p class="text-[#706f6c] dark:text-[#A1A09A]">Dukungan teknis 24/7 untuk aplikasi Anda</p>
                </div>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\projects\myappKK\resources\views/services.blade.php ENDPATH**/ ?>