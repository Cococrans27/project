<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <div class="navbar-brand-content">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo" height="40" style="border-radius: 4px;">
                <div class="navbar-brand-text">
                    <span class="navbar-brand-name navbar-brand-name-custom d-block">KK FOTOCOPY</span>
                    <span class="navbar-brand-subtitle">Solusi Cetak Cepat, Hasil Tepat</span>
                </div>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link  <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="#home">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  <?php echo e(request()->routeIs('product') ? 'active' : ''); ?>" href="#all-product">Produk & Layanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  <?php echo e(request()->routeIs('services') ? 'active' : ''); ?>" href="#location">Lokasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="#contact">Kontak</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><?php /**PATH /home/nasril/Music/myappKK/resources/views/components/navbar.blade.php ENDPATH**/ ?>