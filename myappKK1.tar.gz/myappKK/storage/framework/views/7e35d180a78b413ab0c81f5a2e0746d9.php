<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Product - <?php echo e(config('app.name', 'Laravel')); ?></title>
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
            <link rel="preconnect" href="https://fonts.bunny.net">
            <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
        <?php endif; ?>
    </head>
    <body class="bg-[#FDFDFC] dark:bg-[#0a0a0a] mt-5" style="padding-top: 3rem;">
        <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <h1 class="text-4xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-8">
                Produk Kami
            </h1>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                    <div class="bg-gradient-to-r from-blue-400 to-blue-600 h-48 flex items-center justify-center">
                        <span class="text-white text-4xl">📱</span>
                    </div>
                    <div class="p-6">
                        <h2 class="text-xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-2">Product 1</h2>
                        <p class="text-[#706f6c] dark:text-[#A1A09A] mb-4">Deskripsi produk pertama kami</p>
                        <button class="w-full px-4 py-2 bg-[#1b1b18] dark:bg-[#eeeeec] text-white dark:text-[#1C1C1A] rounded-sm font-medium hover:bg-[#333333] dark:hover:bg-white transition-colors">
                            Lihat Detail
                        </button>
                    </div>
                </div>

                <div class="border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                    <div class="bg-gradient-to-r from-green-400 to-green-600 h-48 flex items-center justify-center">
                        <span class="text-white text-4xl">💻</span>
                    </div>
                    <div class="p-6">
                        <h2 class="text-xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-2">Product 2</h2>
                        <p class="text-[#706f6c] dark:text-[#A1A09A] mb-4">Deskripsi produk kedua kami</p>
                        <button class="w-full px-4 py-2 bg-[#1b1b18] dark:bg-[#eeeeec] text-white dark:text-[#1C1C1A] rounded-sm font-medium hover:bg-[#333333] dark:hover:bg-white transition-colors">
                            Lihat Detail
                        </button>
                    </div>
                </div>

                <div class="border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                    <div class="bg-gradient-to-r from-purple-400 to-purple-600 h-48 flex items-center justify-center">
                        <span class="text-white text-4xl">🎨</span>
                    </div>
                    <div class="p-6">
                        <h2 class="text-xl font-bold text-[#1b1b18] dark:text-[#EDEDEC] mb-2">Product 3</h2>
                        <p class="text-[#706f6c] dark:text-[#A1A09A] mb-4">Deskripsi produk ketiga kami</p>
                        <button class="w-full px-4 py-2 bg-[#1b1b18] dark:bg-[#eeeeec] text-white dark:text-[#1C1C1A] rounded-sm font-medium hover:bg-[#333333] dark:hover:bg-white transition-colors">
                            Lihat Detail
                        </button>
                    </div>
                </div>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\projects\myappKK\resources\views/product.blade.php ENDPATH**/ ?>