<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beranda - <?php echo e(config('app.name')); ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body class="bg-[#FDFDFC] dark:bg-[#0a0a0a]" style="padding-top: 0.25rem;">
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="hero-section">
        <div class="hero-content text-center ">
            <p class="greeting font-size-5px">Hai, KK Fotocopy</p>
            <h2>
                <span class="highlight">Solusi cepat</span> untuk semua
                <br />kebutuhan cetakmu
            </h2>
            <a href="#all-product" class="btn-cetak">Cetak sekarang</a>
        </div>
        <div class="blur-frame"></div>
    </section>

    <section class="py-5 bg-light">
        <div class="container" background="#fafafa">
            <div class="row g-4 text-center">

                
                <div class="col-md-4">
                    <div class="card shadow-sm h-100 border-0 rounded-4">
                        <div class="card-body">
                            <div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>
                            


                            <h5 class="card-title fw-bold">Cepat & Tepat Waktu</h5>
                            <p class="card-text text-muted">
                                Butuh hasil cepat tanpa drama? Kami proses pesananmu dengan efisien dan akurat,
                                jadi kamu bisa langsung lanjut ke hal penting berikutnya.
                            </p>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4">
                    <div class="card shadow-sm h-100 border-0 rounded-4">
                        <div class="card-body">
                            <div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>

                            <h5 class="card-title fw-bold">Kualitas Terjamin</h5>
                            <p class="card-text text-muted">
                                Setiap cetakan kami pastikan tajam, bersih, dan rapi — karena hasil akhir yang keren itu
                                bukan cuma janji, tapi standar kami.
                            </p>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4">
                    <div class="card shadow-sm h-100 border-0 rounded-4">
                        <div class="card-body">
                            <div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>

                            <h5 class="card-title fw-bold">Harga Bersahabat</h5>
                            <p class="card-text text-muted">
                                Kualitas tinggi tak harus mahal. Dengan harga yang tetap ramah di kantong,
                                semua bisa cetak tanpa ragu.
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="py-5 bg-light">
        <div class="container">

            <h2 class="text-center fw-bold mb-2">Cocok Untuk Siapa Saja?</h2>
            <p class="text-center text-muted mb-4">
                Semua bisa cetak di sini — dari pelajar sampai pebisnis.
            </p>

            <div class="row g-3">

                
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="fs-3">📘</div>
                            <div>
                                <h5 class="fw-bold">Pelajar & Mahasiswa</h5>
                                <p class="text-muted mb-0">
                                    Butuh print tugas, laporan, atau skripsi cepat? Semua bisa!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="fs-3">🏢</div>
                            <div>
                                <h5 class="fw-bold">Instansi & Perusahaan</h5>
                                <p class="text-muted mb-0">
                                    Cetak ID card, dokumen resmi, dan kebutuhan promosi.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="fs-3">📋</div>
                            <div>
                                <h5 class="fw-bold">Guru & Tenaga Pendidik</h5>
                                <p class="text-muted mb-0">
                                    Modul, jadwal, sertifikat, hingga materi pembelajaran.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="fs-3">✉️</div>
                            <div>
                                <h5 class="fw-bold">Penyelenggara Acara</h5>
                                <p class="text-muted mb-0">
                                    Undangan, spanduk, backdrop, dan kebutuhan event lain.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="fs-3">📄</div>
                            <div>
                                <h5 class="fw-bold">Pebisnis & UMKM</h5>
                                <p class="text-muted mb-0">
                                    Banner, brosur, dan kartu nama agar usahamu makin dikenal.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="fs-3">🏛️</div>
                            <div>
                                <h5 class="fw-bold">Organisasi & Partai</h5>
                                <p class="text-muted mb-0">
                                    Atribut kampanye, brosur, dan kebutuhan organisasi.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    
    <section class="py-5 popular-section text-white">
        <div class="container">
            <div class="row align-items-center">

                
                <div class="col-md-4 mb-4 mb-md-0">
                    <h2 class="fw-bold mb-2">Pilihan Terpopuler</h2>
                    <p class="mb-0">
                        Produk-produk yang paling sering dipilih pelanggan.
                    </p>
                </div>

                
                <div class="col-md-8">
                    <div class="d-flex gap-3 popular-list">

                        
                        <div class="popular-card">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark">Cetak Banner</h5>
                        </div>

                        
                        <div class="popular-card">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark">Cetak Brosur</h5>
                        </div>

                        
                        <div class="popular-card">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark">Cetak Kartu Nama</h5>
                        </div>

                        
                        <div class="popular-card">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark">Cetak Spanduk</h5>
                        </div>

                        
                    </div>
                </div>

            </div>
        </div>
    </section>
    
    <section id="all-product" class="py-5 bg-light">
        <div class="container">

            
            <div class="text-center mb-4">
                <h2 class="fw-bold">Semua Produk Kami</h2>
                <p class="text-muted mb-0">
                    Semua kebutuhan cetak, dalam satu tempat.
                </p>
            </div>

            
            <div class="row align-items-center mb-4">

                
                <div class="col-md-5 mb-4 mb-md-0">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0">
                            
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                            </svg>

                        </span>
                        <input type="text" class="form-control border-start-" placeholder="Cari">
                    </div>
                </div>

                
                <div class="col-md-7 col-lg-6 ms-md-auto">
                    <div class="d-flex justify-content-md-end justify-content-start gap-2 flex-wrap">
                        <button class="btn btn-outline-secondary rounded-pill btn-sm px-3">Semua</button>
                        <button class="btn btn-outline-secondary rounded-pill btn-sm px-3">Terlaris</button>
                        <button class="btn btn-outline-secondary rounded-pill btn-sm px-3">Flash Sale</button>
                        <button class="btn btn-outline-secondary rounded-pill btn-sm px-3">Baru</button>
                    </div>
                </div>

            </div>


            
            <div class="row g-4">

                <?php for($i = 0; $i < 8; $i++): ?>
                    <div class="col-7 col-md-3">
                        <div class="card border-0 shadow-sm rounded-4 h-100 position-relative">

                            
                            <span
                                class="badge bg-success-subtle text-success border position-absolute top-0 start-0 m-3 rounded-pill">
                                Baru
                            </span>

                            <div class="card-body d-flex flex-column align-items-center">

                                
                                <div class="w-100 bg-light mb-4 rounded-3" style="height: 150px;"></div>

                                
                                <p class="fw-semibold mb-0 text-center">Cetak Banner</p>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>

            </div>
          
            <section class="py-5">
    <div class="container">
        <h4 class="text-center mb-3">Temukan Kami Disini</h4>
        <h6 class="text-center mb-4">Datang Langsung, Kami Siap Bantu Kebutuhan cetakmu.</h6>
        
       <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d247.1987929623117!2d112.6973135!3d-7.5552679!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7df004ad94b25%3A0xba6706a9d1ce2c1b!2sKK%20Fotokopi%20(Cabang%20Utama)!5e0!3m2!1sid!2sid!4v1766032300754!5m2!1sid!2sid" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
       
       
       
        <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kontak & Sosial Media</title>

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="style.css">
</head>
<body>

<section class="contact-section">
    <h2>Kontak & Sosial Media</h2>
    <p class="subtitle">Hubungi kami kapan saja.</p>
    <span class="divider"></span>

    <div class="card-wrapper">

        <!-- Card 1 -->
        <div class="contact-card">
            <i class="fab fa-whatsapp icon-title"></i>
            <h3>WhatsApp</h3>
            <p class="desc">Kirimkan file & berkasmu di sini</p>

            <div class="icon-circle"></div>

            <p class="contact-info">0822-2727-6341</p>
            <a href="#" class="btn">Hubungi Sekarang</a>
        </div>

        <!-- Card 2 -->
        <div class="contact-card">
            <i class="fab fa-whatsapp icon-title"></i>
            <h3>WhatsApp</h3>
            <p class="desc">Pesan dalam jumlah banyak</p>

            <div class="icon-circle"></div>

            <p class="contact-info">0812-3577-3821</p>
            <a href="#" class="btn">Hubungi Sekarang</a>
        </div>

        <!-- Card 3 -->
        <div class="contact-card">
            <i class="fab fa-instagram icon-title"></i>
            <h3>Instagram</h3>
            <p class="desc">Lihat portofolio & promo terbaru</p>

            <div class="icon-circle"></div>

            <p class="contact-info">@kkgroupid</p>
            <a href="#" class="btn">Ikuti Sekarang</a>
        </div>

    </div>
</section>

</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Footer KK Fotocopy</title>
    <link rel="stylesheet" href="style.css">

    <!-- Font Awesome untuk icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<footer class="footer">
    <div class="footer-container">

        <!-- Kiri -->
        <div class="footer-left">
            <img src="logo.png" alt="KK Fotocopy" class="logo">
            <h3>KK Fotocopy</h3>
            <p>Solusi Cetak Cepat, Hasil Tepat.</p>
        </div>

        <!-- Tengah -->
        <div class="footer-center">
            <h4>Navigasi Cepat</h4>
            <ul>
                <li><a href="#">Beranda</a></li>
                <li><a href="#">Produk & Layanan</a></li>
                <li><a href="#">Lokasi</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
        </div>

        <!-- Kanan -->
        <div class="footer-right">
            <h4>Social Media</h4>
            <div class="social-icons">
                <a href="#"><i class="fab fa-whatsapp"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>

    </div>
</footer>

</body>
</html>


            
            <div class="text-center mt-4">
                <a href="<?php echo e(route('product')); ?>" class="fw-semibold text-decoration-none">
                    Tampilkan Keseluruhan ↓
                </a>
            </div>
            <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>

</body>

</html><?php /**PATH C:\projects\myappKK\resources\views/home.blade.php ENDPATH**/ ?>