<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beranda - <?php echo e(config('app.name')); ?></title>
    <!-- google font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/a99d57231c.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body class="bg-[#FDFDFC] dark:bg-[#0a0a0a]" style="padding-top: 0.25rem;">
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <section class="hero-section" id="home">
        <div class="hero-content text-center ">
            <p class="greeting fs-2">Hai, KK Fotocopy</p>
            <h1 class="display-3">
                <span class="highlight">Solusi cepat</span> untuk semua
                <br>kebutuhan cetakmu
            </h1>
        </div>
        <a href="#all-product" class="btn-cetak fs-5 px-5 py-3">Cetak sekarang</a>
        <div class="blur-frame"></div>
    </section>
    <div class="container">
        <section class="py-5">
            <div class="row g-4 text-center">
                
                <div class="col-md-4">
                    <div class="card h-100 border-0 rounded-4">
                        <div class="card-body">
                            <div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>
                            

                            <h5 class="card-title fw-bold fs-5">Cepat & Tepat Waktu</h5>
                            <p class="card-text text-muted fs-6">
                                Butuh hasil cepat tanpa drama? Kami proses pesananmu dengan efisien dan akurat,
                                jadi kamu bisa langsung lanjut ke hal penting berikutnya.
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card h-100 border-0 rounded-4">
                        <div class="card-body">
                            <div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>

                            <h5 class="card-title fw-bold fs-5">Kualitas Terjamin</h5>
                            <p class="card-text text-muted fs-6">
                                Setiap cetakan kami pastikan tajam, bersih, dan rapi — karena hasil akhir yang keren itu
                                bukan cuma janji, tapi standar kami.
                            </p>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4">
                    <div class="card h-100 border-0 rounded-4">
                        <div class="card-body">
                            <div class="bg-secondary bg-opacity-10 rounded-4 mb-3" style="height:270px;"></div>

                            <h5 class="card-title fw-bold fs-5">Harga Bersahabat</h5>
                            <p class="card-text text-muted fs-6">
                                Kualitas tinggi tak harus mahal. Dengan harga yang tetap ramah di kantong,
                                semua bisa cetak tanpa ragu.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="customer-target py-5">
            <h2 class="text-center fw-bold mb-2 fs-2">Cocok Untuk Siapa Saja?</h2>
            <p class="text-center text-muted mb-4 fs-4">
                Semua bisa cetak di sini — dari pelajar sampai pebisnis.
            </p>

            <div class="row row-cols-1 row-cols-md-2 g-3">
                
                <div class="col">
                    <div class="card card-cust-page h-100 rounded-4 p-3">
                        <div class="d-flex align-items-center gap-3 h-100">
                            <div
                                class="icon-cust-section d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa-solid fa-book-open" style="color: #2d2d2d;"></i>
                            </div>
                            <div class="h-100 d-flex flex-column justify-content-center">
                                <h5 class="fw-bold fs-5">Pelajar & Mahasiswa</h5>
                                <p class="text-muted mb-0 fs-6">
                                    Butuh print tugas, laporan, atau skripsi cepat? Semua bisa!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col">
                    <div class="card card-cust-page h-100 rounded-4 p-3">
                        <div class="d-flex align-items-center gap-3 h-100">
                            <div
                                class="icon-cust-section d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa-regular fa-building" style="color: #2d2d2d;"></i>
                            </div>
                            <div class="h-100 d-flex flex-column justify-content-center">
                                <h5 class="fw-bold fs-5">Instansi & Perusahaan</h5>
                                <p class="text-muted mb-0 fs-6">
                                    Cetak ID card, dokumen resmi, dan kebutuhan promosi.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col">
                    <div class="card card-cust-page h-100 rounded-4 p-3">
                        <div class="d-flex align-items-center gap-3 h-100">
                            <div
                                class="icon-cust-section d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa-regular fa-clipboard" style="color: #2d2d2d;"></i>
                            </div>
                            <div class="h-100 d-flex flex-column justify-content-center">
                                <h5 class="fw-bold fs-5">Guru & Tenaga Pendidik</h5>
                                <p class="text-muted mb-0 fs-6">
                                    Modul, jadwal, sertifikat, hingga materi pembelajaran.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col">
                    <div class="card card-cust-page h-100 rounded-4 p-3">
                        <div class="d-flex align-items-center gap-3 h-100">
                            <div
                                class="icon-cust-section d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa-regular fa-envelope" style="color: #2d2d2d;"></i>
                            </div>
                            <div class="h-100 d-flex flex-column justify-content-center">
                                <h5 class="fw-bold fs-5">Penyelenggara Acara</h5>
                                <p class="text-muted mb-0 fs-6">
                                    Undangan, spanduk, backdrop, dan kebutuhan event lain.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col">
                    <div class="card card-cust-page h-100 rounded-4 p-3">
                        <div class="d-flex align-items-center gap-3 h-100">
                            <div
                                class="icon-cust-section d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa-regular fa-chart-bar" style="color: #2d2d2d;"></i>
                            </div>
                            <div class="h-100 d-flex flex-column justify-content-center">
                                <h5 class="fw-bold fs-5">Pebisnis & UMKM</h5>
                                <p class="text-muted mb-0 fs-6">
                                    Banner, brosur, dan kartu nama agar usahamu makin dikenal.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col">
                    <div class="card card-cust-page h-100 rounded-4 p-3">
                        <div class="d-flex align-items-center gap-3 h-100">
                            <div
                                class="icon-cust-section d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa-regular fa-flag" style="color: #2d2d2d;"></i>
                            </div>
                            <div class="h-100 d-flex flex-column justify-content-center">
                                <h5 class="fw-bold fs-5">Organisasi & Partai</h5>
                                <p class="text-muted mb-0 fs-6">
                                    Atribut kampanye, brosur, dan kebutuhan organisasi.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    
    <section class="py-5 popular-section text-white">
        <div class="container">
            <div class="row align-items-center">
                
                <div class="title-popular-product col-md-4 mb-4 mb-md-0">
                    <h2 class="fw-bold mb-2 fs-2">Pilihan Terpopuler</h2>
                    <p class="mb-0 fs-4">
                        Produk-produk yang paling sering dipilih pelanggan.
                    </p>
                </div>
                
                <div class="col-md-8 overflow-visible">
                    <div class="d-flex gap-3 popular-list">

                        
                        <div class="popular-card rounded-5">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark fs-6">Cetak Banner</h5>
                        </div>

                        
                        <div class="popular-card rounded-5">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark fs-6">Cetak Brosur</h5>
                        </div>

                        
                        <div class="popular-card rounded-5">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark fs-6">Cetak Kartu Nama</h5>
                        </div>

                        
                        <div class="popular-card rounded-5">
                            <div class="popular-card-image mb-3"></div>
                            <h5 class="text-center mb-0 text-dark fs-6">Cetak Spanduk</h5>
                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <div class="container">
        <section id="all-product" class="py-5">
            
            <div class="title-all-product mb-4">
                <h2 class="fw-bold fs-2">Semua Produk Kami</h2>
                <p class="text-muted mb-0 fs-4">
                    Semua kebutuhan cetak, dalam satu tempat.
                </p>
            </div>

            
            <div class="row align-items-center mb-4">
                
                <div class="col-md-5 mb-4 mb-md-0">
                    <div class="input-group px-1 g-0 rounded-pill">
                        <span class="input-group-text bg-transparent border-0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                            </svg>
                        </span>
                        <input type="text" class="form-control bg-transparent border-0 ps-0" placeholder="Cari">
                    </div>
                </div>

                
                <div class="col-md-7 col-lg-6 ms-md-auto">
                    <div class="d-flex justify-content-md-end justify-content-start gap-2 flex-wrap">
                        <button class="btn btn-filter-product rounded-pill btn-sm px-4 py-2 fs-6">Semua</button>
                        <button class="btn btn-filter-product rounded-pill btn-sm px-4 py-2 fs-6">Terlaris</button>
                        <button class="btn btn-filter-product rounded-pill btn-sm px-4 py-2 fs-6">Flash Sale</button>
                        <button class="btn btn-filter-product rounded-pill btn-sm px-4 py-2 fs-6">Baru</button>
                    </div>
                </div>

            </div>


            <div class="row row-cols-1 row-cols-md-4 g-4">
                
                <?php for($i = 0; $i < 8; $i++): ?>
                <div class="col">
                    <div class="card rounded-4 h-100">
                        <div class="card-body">
                            <div class="w-100 bg-light mb-4 rounded-3 d-flex position-relative" style="height: 150px;">
                                <span class="badge bg-success-subtle text-success border position-absolute top-0 end-0 mt-2 me-2 rounded-pill fs-6 fw-medium">
                                    Baru
                                </span>
                                
                            </div>
                            
                            <p class="fw-semibold mb-0 text-center fs-6">Cetak Banner</p>
                        </div>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </section>
        <section class="store-location text-center" id="location">
            <h2 class="fw-bold fs-2">Temukan Kami Di sini</h2>
            <p class="mb-4 fs-4">Datang Langsung, Kami Siap Bantu Kebutuhan cetakmu.</p>
            
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d247.1987929623117!2d112.6973135!3d-7.5552679!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7df004ad94b25%3A0xba6706a9d1ce2c1b!2sKK%20Fotokopi%20(Cabang%20Utama)!5e0!3m2!1sid!2sid!4v1766032300754!5m2!1sid!2sid"
                width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade" class="rounded-4"></iframe>
        </section>
        <section class="contact-section" id="contact">
            <h2 class="fw-bold fs-2">Kontak & Sosial Media</h2>
            <p class="subtitle fs-4">Hubungi kami kapan saja.</p>

            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                    <div class="card contact-card d-flex flex-column align-items-center text-center h-100 rounded-4">
                        <i class="fab fa-whatsapp icon-title fs-3"></i>
                        <h5 class="fs-5">WhatsApp</h5>
                        <p class="desc fs-6">Kirimkan file & berkasmu di sini</p>

                        <div class="icon-circle">
                            <img src="" alt="">
                        </div>

                        <p class="contact-info fs-6 fw-medium">0822-2727-6341</p>
                        <a href="#" class="btn btn-secondary px-4 py-2 rounded-pill w-100">Hubungi Sekarang</a>
                    </div>
                </div>
                <div class="col">
                    <div class="card contact-card d-flex flex-column align-items-center text-center h-100 rounded-4">
                        <i class="fab fa-whatsapp icon-title fs-3"></i>
                        <h5 class="fs-5">WhatsApp</h5>
                        <p class="desc fs-6">Pesan dalam jumlah banyak</p>

                        <div class="icon-circle">
                            <img src="" alt="">
                        </div>

                        <p class="contact-info fs-6 fw-medium">0812-3577-3821</p>
                        <a href="#" class="btn btn-secondary px-4 py-2 rounded-pill w-100">Hubungi Sekarang</a>
                    </div>
                </div>
                <div class="col">
                    <div class="card contact-card d-flex flex-column align-items-center text-center h-100 rounded-4">
                        <i class="fa fa-instagram icon-title fs-3" style="color: #2d2d2d;"></i>
                        <h5 class="fs-5">Instagram</h5>
                        <p class="desc fs-6">Lihat portofolio & promo terbaru</p>

                        <div class="icon-circle">
                            <img src="" alt="">
                        </div>

                        <p class="contact-info fs-6 fw-medium">@kkgroupid</p>
                        <a href="#" class="btn btn-secondary px-4 py-2 rounded-pill w-100">Ikuti Sekarang</a>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html><?php /**PATH D:\Kuliah\Semester 1\Algoritma dan Pemrograman\myappKK\resources\views/home.blade.php ENDPATH**/ ?>