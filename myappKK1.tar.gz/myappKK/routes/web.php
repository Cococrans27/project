<?php

use Illuminate\Support\Facades\Route;


// Home route
Route::get('/', function () {
    return view('home');
})->name('home');

// Product route
Route::get('/product', function () {
    return view('product');
})->name('product');

// About route
Route::get('/about', function () {
    return view('about');
})->name('about');

// Services route
Route::get('/services', function () {
    return view('services');
})->name('services');

// Contact route
Route::get('/contact', function () {
    return view('contact');
})->name('contact');